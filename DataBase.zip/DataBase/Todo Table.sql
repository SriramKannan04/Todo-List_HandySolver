USE handysolver;
SHOW TABLES;
SELECT * FROM catagory;
